﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace Master
{
    public partial class New_student1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           cv2.ValueToCompare = DateTime.Now.ToString("dd/MM/yyyy");
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Trainings"].ConnectionString);
                SqlCommand cmd = new SqlCommand("insert into student_master values(@stdcode,@stdname,@deptcode,@dob,@add)", con);
                cmd.Parameters.AddWithValue("@stdcode", txtstdcode.Text);
                cmd.Parameters.AddWithValue("@stdname", txtstdname.Text);
                cmd.Parameters.AddWithValue("@deptcode", txtdeptcode.Text);
                cmd.Parameters.AddWithValue("@dob", txtdob.Text);
                cmd.Parameters.AddWithValue("@add", ddladdress.SelectedItem.Text);
                con.Open();
                int ra = cmd.ExecuteNonQuery();
                con.Close();
                if (ra > 0)
                {
                   
                    Response.Write("<script> alert('success')</script>");
                }
            }
            catch(Exception ex)
            {
                string a = ex.Message;
                Response.Write("<script> alert(ex.Message)</script>");
            }
        }

        protected void cv3_ServerValidate(object source, ServerValidateEventArgs args)
        {
            DateTime minDate = DateTime.Parse("2019/01/01");
            DateTime maxDate = DateTime.Parse("2019/12/31");
            DateTime dt =Convert.ToDateTime( args.Value);
            if(dt<=maxDate && dt>=minDate)
            {
                args.IsValid = true;
            }
            else { args.IsValid = false; }
            //args.IsValid = (DateTime.TryParse(args.Value, out dt)
            //                && dt <= maxDate
            //                && dt >= minDate);

        }
    }
}