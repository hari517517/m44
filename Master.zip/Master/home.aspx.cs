﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace Master
{
    public partial class home : System.Web.UI.Page
    {
        SqlConnection con; SqlCommand cmd;SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["Trainings"].ConnectionString);
                cmd = new SqlCommand("select * from student_master", con);

                con.Open();
                 dr = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(dr); 
                gvhome.DataSource = dt;
                gvhome.DataBind();
            }
            catch(Exception ex)
            {
                Response.Write("<script> alert(ex.Message)</script>");
            }
            finally { con.Close(); }
        }

      
    }
}