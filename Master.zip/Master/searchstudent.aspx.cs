﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using System.Web.UI.HtmlControls;

namespace Master
{
    public partial class searchstudent : System.Web.UI.Page
    {
        SqlConnection con;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void submit_Click(object sender, EventArgs e)
        {
            
        }

        protected void searchbtn_Click(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["Trainings"].ConnectionString);
                SqlCommand cmd = new SqlCommand("select * from student_master where stud_code=@stdcode", con);
                cmd.Parameters.AddWithValue("@stdcode", txtstdcode.Text);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    string a = dr["Address"].ToString();
                    if(a=="Pune")
                    {
                        ddladdress.SelectedIndex = 0;
                    }
                    else if (a == "Srikakulam") { ddladdress.SelectedIndex = 1; }
                    else if (a == "Gara") { ddladdress.SelectedIndex = 2; }
                    else if (a == "Mumbai") { ddladdress.SelectedIndex = 3; }
                    txtdeptcode.Text = dr["Dept_Code"].ToString();
                    txtstdname.Text = dr["Stud_name"].ToString();
                    txtdob.Text = dr["Stud_Dob"].ToString();
                    txtstdcode.ReadOnly = true;
                    table2.Visible = true;

                }
                else
                {
                    Response.Write("<script>alert('not found')</script>");
                }
            }
            catch(Exception ex)
            {
                Response.Write("<script>alert(ex.Message)</script>");
            }
            finally { con.Close(); }
            

        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["Trainings"].ConnectionString);
                SqlCommand cmd = new SqlCommand("delete from student_master where stud_code=@stdcode", con);
                cmd.Parameters.AddWithValue("@stdcode", txtstdcode.Text);

                con.Open();
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                    Response.Write("<script>alert('deleted')</script>");

                }

                con.Close();
                table2.Visible = false;
                txtstdcode.ReadOnly = false;
                txtstdcode.Text = null;
            }
            catch(Exception ex)
            {
                Response.Write("<script>alert(ex.Message)</script>");
            }
            finally { con.Close(); }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                 con = new SqlConnection(ConfigurationManager.ConnectionStrings["Trainings"].ConnectionString);
                SqlCommand cmd = new SqlCommand("update student_master set stud_name=@stdname,dept_code=@deptcode,stud_dob=@dob,address=@add where  stud_code=@stdcode", con);
              
                cmd.Parameters.AddWithValue("@stdname",txtstdname.Text);
                cmd.Parameters.AddWithValue("@deptcode", txtdeptcode.Text);
                cmd.Parameters.AddWithValue("@dob", txtdob.Text);
                cmd.Parameters.AddWithValue("@add", ddladdress.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@stdcode", txtstdcode.Text);
                con.Open();
                int ra = cmd.ExecuteNonQuery();
                
                if (ra > 0)
                {

                    Response.Write("<script> alert('updated')</script>");
                }
                table2.Visible = false;
                txtstdcode.ReadOnly = false;
                txtstdcode.Text = null;
            }
            catch (Exception ex)
            {
                Response.Write("<script> alert(ex.Message)</script>");
            }
            finally { con.Close(); }
        }
    }
}